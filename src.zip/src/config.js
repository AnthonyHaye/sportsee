const CONFIG = {
  useMockData: false, // Passe à `false` pour utiliser les données de l'API
}

export default CONFIG
